package bdg.bdk.kertasguntingbatucomplayer;

import android.app.Activity;

public class MenuActivity extends Activity {
}
